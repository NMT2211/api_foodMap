package CONTROLER;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import DAOS.FavoriteDaoImpl;
import DAOS.UserDaoImpl;
import DAOS.VideoDaoImpl;
import ENTITYS.favoriteEntity;
import ENTITYS.userEntity;
import ENTITYS.videoEntity;

/**
 * Servlet implementation class admin
 */
@MultipartConfig(
	    location = "D:/Eclipse_2024/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/wtpwebapps/ASM_Java4/img/", // Thư mục lưu trữ file upload
	    maxFileSize = 1024 * 1024 * 10, // Giới hạn kích thước file tối đa (10MB)
	    maxRequestSize = 1024 * 1024 * 50, // Giới hạn kích thước request (50MB)
	    fileSizeThreshold = 1024 * 1024 // Giới hạn tạm thời trước khi lưu vào disk
	)
@WebServlet({
    "/admin",
    "/admin/home", "/admin/user", "/admin/video", "/admin/report",
    "/admin/user/edit/*", "/admin/user/create", "/admin/user/update", "/admin/user/delete", "/admin/user/delete/*", "/admin/user/reset",
    "/admin/video/edit/*", "/admin/video/create", "/admin/video/update", "/admin/video/delete", "/admin/video/delete/*", "/admin/video/reset",
})
public class admin extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public admin() {
        super();
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        res.setCharacterEncoding("utf-8");

        String path = req.getRequestURI();

        if (path.contains("video")) {
            // Quản lý video
            QLvideo(req, res, path);
        }else if (path.contains("user")) {
            // Quản lý video
            QLuser(req, res, path);
        }else if (path.contains("report")) {
            // Quản lý video
        	report(req, res, path);
        }
        // Chuyển tiếp đến trang quản trị
        req.getRequestDispatcher("/view/admin/admin.jsp").forward(req, res);
    }

    private void QLvideo(HttpServletRequest req, HttpServletResponse res, String path) {
        VideoDaoImpl dao = new VideoDaoImpl();
        videoEntity form = new videoEntity();

        String uploadDir = "D:\\Eclipse_2024\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\ASM_Java4\\img";
        String existingImage = null; // Khai báo để lưu ảnh cũ

        try {
            // Kiểm tra xem yêu cầu có phải là multipart (upload file)
            if (req.getContentType() != null && req.getContentType().startsWith("multipart/form-data")) {
                for (Part part : req.getParts()) {
                    String fieldName = part.getName();
                    if (part.getSize() > 0) {
                        if (fieldName.equals("file")) {
                            // Xử lý file upload
                            String fileName = part.getSubmittedFileName();
                            if (fileName != null && !fileName.isEmpty()) {
                                File dir = new File(uploadDir);
                                if (!dir.exists()) {
                                    dir.mkdirs(); // Tạo thư mục nếu chưa tồn tại
                                }

                                File storeFile = new File(uploadDir + fileName);
                                // Xóa tệp cũ nếu tồn tại
                                if (storeFile.exists()) {
                                    storeFile.delete();
                                }

                                part.write(storeFile.getAbsolutePath()); // Lưu tệp lên hệ thống
                                form.setPoster(fileName); // Lưu tên file vào form
                            }
                        }
                    } else {
                        // Xử lý các trường khác trong form (không phải file)
                        String fieldValue = req.getParameter(fieldName);

                        // Lưu tên ảnh cũ nếu có
                        if (fieldName.equals("existingImage")) {
                            existingImage = fieldValue;
                        }

                        BeanUtils.setProperty(form, fieldName, fieldValue);
                    }
                }

                // Nếu không upload ảnh mới, giữ lại ảnh cũ
                if (form.getPoster() == null || form.getPoster().isEmpty()) {
                    form.setPoster(existingImage);
                }
            } else {
                // Nếu không phải upload file, xử lý các trường còn lại
                BeanUtils.populate(form, req.getParameterMap());
            }
        } catch (Exception e) {
            e.printStackTrace(); // Xử lý lỗi upload file và các lỗi khác
        }

        // Xử lý các thao tác CRUD
        if (path.contains("edit")) {
            String id = req.getPathInfo().substring(1); // Lấy ID từ URL
            form = dao.findById(id); // Lấy video theo ID
        } else if (path.contains("create")) {
            dao.create(form);
            form = new videoEntity();
        } else if (path.contains("update")) {
            dao.update(form);
        } else if (path.contains("delete")) {
            String idToDelete = req.getPathInfo().substring(1);
            dao.deleteById(idToDelete); // Xóa video theo ID
            form = new videoEntity();
        } else {
            form = new videoEntity();
        }

        // Đặt video hiện tại vào request để hiển thị
        req.setAttribute("item", form);
        List<videoEntity> list = dao.findAll();

        req.setAttribute("listall", list); // Đặt danh sách video vào request
        req.setAttribute("view", "/view/admin/quanlivideo.jsp"); // Chuyển tiếp đến trang quản lý video
    }
    
    
    private void QLuser(HttpServletRequest req, HttpServletResponse res, String path) {
        UserDaoImpl dao = new UserDaoImpl();
        userEntity form = new userEntity();
        try {
			BeanUtils.populate(form, req.getParameterMap());
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        // Xử lý các thao tác CRUD
        if (path.contains("edit")) {
            
            String id = req.getPathInfo().substring(1); // Lấy ID từ URL
            form = dao.findById(id); // Lấy video theo ID
        } else if (path.contains("create")) {
            
            dao.create(form);
            form = new userEntity();
        } else if (path.contains("update")) {
            
            dao.update(form);
        } else if (path.contains("delete")) {
            String idToDelete = req.getPathInfo().substring(1);
            dao.deleteById(idToDelete); // Xóa tin tức theo ID
            form = new userEntity();
        } else {
            form = new userEntity();
        }

        
        req.setAttribute("item", form);
        List<userEntity> list = dao.findAll();

        req.setAttribute("listall", list); 
        req.setAttribute("view", "/view/admin/quanliuser.jsp"); 
    }
    
    private void report(HttpServletRequest req, HttpServletResponse res, String path) {
        UserDaoImpl dao = new UserDaoImpl();
        FavoriteDaoImpl daof = new FavoriteDaoImpl();
        VideoDaoImpl daov = new VideoDaoImpl();
        userEntity form = new userEntity();
        try {
			BeanUtils.populate(form, req.getParameterMap());
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        

        
        
        List<Object[]> listFavorite = daov.findVideoLikeStats();
        req.setAttribute("listFavorite", listFavorite); 
        
        
        req.setAttribute("view", "/view/admin/report.jsp"); 
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
