package DAOS;

import java.util.List;

import ENTITYS.videoEntity;

public interface VideoDao {
    List<videoEntity> findAll(); // Lấy danh sách tất cả video
    videoEntity findById(String id); // Tìm video theo ID
    boolean create(videoEntity item); // Tạo video mới
    boolean update(videoEntity item); // Cập nhật video
    boolean deleteById(String id); // Xóa video theo ID
    List<Object[]> findVideoLikeStats(); // Lấy thống kê lượt thích của video
    List<videoEntity> findVideosNotLiked(); // Tìm video chưa được thích
    List<videoEntity> findVideosSharedInYear(int year); // Tìm video được chia sẻ trong năm
    List<videoEntity> findByTitle(String title); // Tìm video theo tiêu đề
}
