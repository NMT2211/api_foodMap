
package DAOS;

public interface ShareDao {
	
}
