package DAOS;

import java.util.List;

import ENTITYS.userEntity;

public interface UserDao {
    List<userEntity> findAll(); // Lấy tất cả người dùng
    List<userEntity> finduser(); 
    
    userEntity findById(String id); // Tìm người dùng theo ID
    List<userEntity> findsearch(String name); // Tìm kiếm người dùng theo tên
    boolean create(userEntity item); // Tạo người dùng mới
    boolean update(userEntity item); // Cập nhật người dùng
    boolean deleteById(String id); // Xóa người dùng theo ID
    List<userEntity> findpage(int pageNo, int pageSize); // Phân trang
    userEntity findIdorEmail(String search); // Tìm kiếm theo ID hoặc email
    userEntity findByResetCode(String resetCode);
}
