package DAOS;

import java.util.List;

import ENTITYS.userEntity;
import UTILS.XJPA;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;

public class UserDaoImpl implements UserDao {

    private EntityManager em = XJPA.getEntityManager();

    // Câu lệnh JPQL chung
    private static final String JSQL_FIND_ALL = "SELECT o FROM userEntity o";

    @Override
    public List<userEntity> findpage(int pageNo, int pageSize) {
        TypedQuery<userEntity> query = em.createQuery(JSQL_FIND_ALL, userEntity.class);
        query.setFirstResult((pageNo - 1) * pageSize);
        query.setMaxResults(pageSize);
        return query.getResultList();
    }

    @Override
    public List<userEntity> findAll() {
        TypedQuery<userEntity> query = em.createQuery(JSQL_FIND_ALL, userEntity.class);
        return query.getResultList();
    }
    
    
    public List<userEntity> finduser() {
    	String sql= "SELECT o FROM userEntity o Where o.admin = false ";
        TypedQuery<userEntity> query = em.createQuery(sql, userEntity.class);
        return query.getResultList();
    }


    @Override
    public userEntity findById(String id) {
        try {
            return em.find(userEntity.class, id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<userEntity> findsearch(String name) {
        String jpql = "SELECT o FROM userEntity o WHERE o.fullname LIKE :search";
        TypedQuery<userEntity> query = em.createQuery(jpql, userEntity.class);
        query.setParameter("search", "%" + name + "%");
        return query.getResultList();
    }

    @Override
    public userEntity findIdorEmail(String search) {
        String jpql = "SELECT o FROM userEntity o WHERE o.id = :search OR o.email = :search";
        TypedQuery<userEntity> query = em.createQuery(jpql, userEntity.class);
        query.setParameter("search", search);

        try {
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Override
    public boolean deleteById(String id) {
        if (!em.isOpen()) return false;

        userEntity user = em.find(userEntity.class, id);
        if (user == null) return false;

        try {
            em.getTransaction().begin();
            em.remove(user);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean create(userEntity user) {
        if (!em.isOpen()) return false;

        try {
            em.getTransaction().begin();
            em.persist(user);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(userEntity user) {
        if (!em.isOpen()) return false;

        try {
            em.getTransaction().begin();
            em.merge(user);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public userEntity findByResetCode(String resetCode) {
        String jpql = "SELECT o FROM userEntity o WHERE o.resetCode = :resetCode";
        TypedQuery<userEntity> query = em.createQuery(jpql, userEntity.class);
        query.setParameter("resetCode", resetCode);

        try {
            return query.getSingleResult(); // Trả về đối tượng nếu tìm thấy
        } catch (NoResultException e) {
            return null; // Trả về null nếu không tìm thấy
        }
    }


    // Kiểm tra các thao tác CRUD
    public static void main(String[] args) {
        UserDaoImpl dao = new UserDaoImpl();

        // Ví dụ: Lấy danh sách người dùng không phải Admin
        List<userEntity> nonAdminUsers = dao.finduser();
        if (!nonAdminUsers.isEmpty()) {
            System.out.println("Danh sách người dùng không phải Admin:");
            for (userEntity user : nonAdminUsers) {
                System.out.println("ID: " + user.getId() + ", Fullname: " + user.getFullname());
            }
        } else {
            System.out.println("Không có người dùng nào không phải Admin.");
        }

        
    }

}
