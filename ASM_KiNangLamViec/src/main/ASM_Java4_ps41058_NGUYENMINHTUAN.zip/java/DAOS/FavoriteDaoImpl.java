package DAOS;

import java.util.List;
import ENTITYS.favoriteEntity;
import UTILS.XJPA;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

public class FavoriteDaoImpl implements FavoriteDao {
    EntityManagerFactory factory = Persistence.createEntityManagerFactory("PolyOE");
    public EntityManager em = XJPA.getEntityManager();

    String jsqlfindAll = "SELECT f FROM favoriteEntity f";

    @Override
    public List<favoriteEntity> findAll() {
        TypedQuery<favoriteEntity> query = em.createQuery(jsqlfindAll, favoriteEntity.class);
        return query.getResultList();
    }

    @Override
    public List<favoriteEntity> findLikeById(String id) {
        String jsqlfindByUserId = "SELECT f FROM favoriteEntity f WHERE f.user.id = :search";
        TypedQuery<favoriteEntity> query = em.createQuery(jsqlfindByUserId, favoriteEntity.class);
        query.setParameter("search", id);
        return query.getResultList();
    }

    @Override
    public favoriteEntity findById(String id) {
        return em.find(favoriteEntity.class, id);
    }

    @Override
    public boolean create(favoriteEntity entity) {
        try {
            em.getTransaction().begin();
            em.persist(entity);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(favoriteEntity entity) {
        try {
            em.getTransaction().begin();
            em.merge(entity);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteById(String id) {
        favoriteEntity entity = em.find(favoriteEntity.class, id);
        if (entity == null) {
            return false;
        }
        try {
            em.getTransaction().begin();
            em.remove(entity);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(String userId, String videoId) {
        String jsqlDelete = "DELETE FROM favoriteEntity f WHERE f.user.id = :userId AND f.video.id = :videoId";
        try {
            em.getTransaction().begin();
            int rowsAffected = em.createQuery(jsqlDelete)
                                 .setParameter("userId", userId)
                                 .setParameter("videoId", videoId)
                                 .executeUpdate();
            em.getTransaction().commit();
            return rowsAffected > 0;
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        FavoriteDaoImpl dao = new FavoriteDaoImpl();

        // Xóa video yêu thích của user
        boolean isDeleted = dao.delete("20", "VD15");
        if (isDeleted) {
            System.out.println("Đã xóa yêu thích thành công.");
        } else {
            System.out.println("Không tìm thấy yêu thích để xóa.");
        }
    }

}
