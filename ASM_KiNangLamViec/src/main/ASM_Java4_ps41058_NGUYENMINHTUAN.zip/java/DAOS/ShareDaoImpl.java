package DAOS;

import java.util.List;

import ENTITYS.shareEntity;
import UTILS.XJPA;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;


public class ShareDaoImpl implements ShareDao {
EntityManagerFactory factory = Persistence.createEntityManagerFactory("PolyOE");
	
	
	public EntityManager em = XJPA.getEntityManager();
    
    String jsqlfindAll = "select o from shareEntity o";
    
    
    public List<shareEntity> findVideosSharedIn2024() {
        String jpql = "SELECT s FROM shareEntity s LEFT JOIN s.video v WHERE FUNCTION('YEAR', s.shareDate) = 2024 ORDER BY s.shareDate ASC";
        TypedQuery<shareEntity> query = em.createQuery(jpql, shareEntity.class);
        return query.getResultList();
    }
    public List<shareEntity> findVideosShared() {
        String jpql = "SELECT s FROM shareEntity s LEFT JOIN s.video v  ORDER BY s.shareDate ASC";
        TypedQuery<shareEntity> query = em.createQuery(jpql, shareEntity.class);
        return query.getResultList();
    }

    public static void main(String[] args) {
        // Khởi tạo đối tượng ShareDaoImpl
        ShareDaoImpl dao = new ShareDaoImpl();
        List<shareEntity> shares = dao.findVideosShared();
        
        System.out.println("Danh sách video chia sẻ năm 2024:");
        for (shareEntity share : shares) {
            System.out.println("Video ID: " + share.getVideo().getId() +
                               ", Video Title: " + share.getVideo().getTitle() +
                               ", Email: " + share.getEmails() +
                               ", Share Date: " + share.getShareDate());
        }
    }
    
}
