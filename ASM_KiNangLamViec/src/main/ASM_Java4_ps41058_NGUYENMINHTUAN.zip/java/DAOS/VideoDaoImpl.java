package DAOS;

import java.util.List;
import ENTITYS.videoEntity;
import UTILS.XJPA;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

public class VideoDaoImpl implements VideoDao {

    private EntityManager em = XJPA.getEntityManager();

    private static final String jsqlFindAll = "SELECT v FROM videoEntity v ORDER BY v.views ";

    @Override
    public List<videoEntity> findAll() {
        TypedQuery<videoEntity> query = em.createQuery(jsqlFindAll, videoEntity.class);
        return query.getResultList();
    }

    @Override
    public videoEntity findById(String id) {
        return em.find(videoEntity.class, id);
    }

    @Override
    public boolean create(videoEntity video) {
        try {
            em.getTransaction().begin();
            em.persist(video);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(videoEntity video) {
        try {
            em.getTransaction().begin();
            em.merge(video);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteById(String id) {
        videoEntity video = em.find(videoEntity.class, id);
        if (video == null) {
            return false;
        }
        try {
            em.getTransaction().begin();
            em.remove(video);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Object[]> findVideoLikeStats() {
        String jpql = "SELECT v.title, " +
                      "COUNT(f) AS likeCount, " +
                      "MIN(f.likeDate) AS oldestLikeDate, " +
                      "MAX(f.likeDate) AS newestLikeDate " +
                      "FROM videoEntity v " +
                      "LEFT JOIN favoriteEntity f ON v.id = f.video.id " +
                      "GROUP BY v.id, v.title " +
                      "ORDER BY likeCount DESC";
        TypedQuery<Object[]> query = em.createQuery(jpql, Object[].class);
        return query.getResultList();
    }

    @Override
    public List<videoEntity> findVideosNotLiked() {
        String jpql = "SELECT v FROM videoEntity v " +
                      "LEFT JOIN favoriteEntity f ON v.id = f.video.id " +
                      "WHERE f.id IS NULL";
        TypedQuery<videoEntity> query = em.createQuery(jpql, videoEntity.class);
        return query.getResultList();
    }

    @Override
    public List<videoEntity> findVideosSharedInYear(int year) {
        String jpql = "SELECT v FROM videoEntity v " +
                      "LEFT JOIN shareEntity s ON v.id = s.video.id " +
                      "WHERE YEAR(s.shareDate) = :year " +
                      "ORDER BY s.shareDate ASC";
        TypedQuery<videoEntity> query = em.createQuery(jpql, videoEntity.class);
        query.setParameter("year", year);
        return query.getResultList();
    }

    @Override
    public List<videoEntity> findByTitle(String title) {
        String jpql = "SELECT v FROM videoEntity v WHERE v.title LIKE :title";
        TypedQuery<videoEntity> query = em.createQuery(jpql, videoEntity.class);
        query.setParameter("title", "%" + title + "%");
        return query.getResultList();
    }

    public static void main(String[] args) {
        VideoDaoImpl dao = new VideoDaoImpl();

        // Ví dụ: Thống kê lượt thích của các video
        List<Object[]> videoStats = dao.findVideoLikeStats();
        System.out.println("Thống kê lượt thích video:");
        for (Object[] stats : videoStats) {
            System.out.println("Tiêu đề: " + stats[0] + ", Lượt thích: " + stats[1] +
                               ", Ngày thích cũ nhất: " + stats[2] + ", Ngày thích mới nhất: " + stats[3]);
        }

        // Ví dụ: Lọc video đã chia sẻ trong năm cụ thể
        int year = 2024;
        List<videoEntity> sharedVideos = dao.findVideosSharedInYear(year);
        System.out.println("Danh sách video được chia sẻ năm " + year + ":");
        for (videoEntity video : sharedVideos) {
            System.out.println("ID: " + video.getId() + ", Tiêu đề: " + video.getTitle() + ", Lượt xem: " + video.getViews());
        }
    }
}
