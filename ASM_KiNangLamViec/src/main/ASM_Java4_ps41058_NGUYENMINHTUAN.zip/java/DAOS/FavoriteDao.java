package DAOS;

import java.util.List;
import ENTITYS.favoriteEntity;

public interface FavoriteDao {
    List<favoriteEntity> findAll();                      // Lấy tất cả
    List<favoriteEntity> findLikeById(String id);        // Lấy danh sách yêu thích theo ID user
    favoriteEntity findById(String id);                 // Tìm theo ID
    boolean create(favoriteEntity item);                // Tạo mới
    boolean update(favoriteEntity item);                // Cập nhật
    boolean deleteById(String id);                      // Xóa theo ID
    boolean delete(String userId, String videoId) ;
}
