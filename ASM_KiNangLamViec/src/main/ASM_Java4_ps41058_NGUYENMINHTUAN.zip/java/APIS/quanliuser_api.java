package APIS;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import DAOS.UserDao;
import DAOS.UserDaoImpl;
import ENTITYS.userEntity;

@WebServlet({"/quanliuser_api", "/quanliuser_api/*"})
public class quanliuser_api extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final UserDao userDao = new UserDaoImpl();

    public quanliuser_api() {
        super();
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
        response.setHeader("Access-Control-Max-Age", "3600");

        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            response.setStatus(HttpServletResponse.SC_OK);
            return;
        }

        super.service(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (PrintWriter out = response.getWriter()) {
            List<userEntity> users = userDao.finduser();
            JSONArray jsonArray = new JSONArray();
            for (userEntity user : users) {
                jsonArray.put(toJson(user));
            }
            out.print(jsonArray.toString());
        } catch (Exception e) {
            sendError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi server: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (BufferedReader reader = request.getReader(); PrintWriter out = response.getWriter()) {
            JSONObject inputJson = new JSONObject(readRequestBody(reader));

            String id = inputJson.optString("id");
            String fullname = inputJson.optString("fullname");
            String email = inputJson.optString("email");
            String password = inputJson.optString("password");

            userEntity user = userDao.findById(id);

            if (user == null) {
                sendError(response, HttpServletResponse.SC_NOT_FOUND, "Người dùng không tồn tại.");
                return;
            }

            if (!fullname.isEmpty()) user.setFullname(fullname.trim());
            if (!email.isEmpty()) user.setEmail(email.trim());
            if (!password.isEmpty()) user.setPassword(password.trim());

            boolean isUpdated = userDao.update(user);

            if (isUpdated) {
                response.setStatus(HttpServletResponse.SC_OK);
                JSONObject successResponse = new JSONObject();
                successResponse.put("id", user.getId());
                successResponse.put("message", "Cập nhật thông tin thành công.");
                out.print(successResponse.toString());
            } else {
                sendError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Không thể cập nhật thông tin.");
            }
        } catch (Exception e) {
            sendError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi server: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (PrintWriter out = response.getWriter()) {
            String pathInfo = request.getPathInfo();

            if (pathInfo == null || pathInfo.length() <= 1) {
                sendError(response, HttpServletResponse.SC_BAD_REQUEST, "Yêu cầu không hợp lệ.");
                return;
            }

            String id = pathInfo.substring(1); // Lấy ID từ URL
            boolean isDeleted = userDao.deleteById(id);

            if (isDeleted) {
                response.setStatus(HttpServletResponse.SC_OK);
                JSONObject successResponse = new JSONObject();
                successResponse.put("id", id);
                successResponse.put("message", "Xóa người dùng thành công.");
                out.print(successResponse.toString());
            } else {
                sendError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Không thể xóa người dùng.");
            }
        } catch (Exception e) {
            sendError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi server: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private JSONObject toJson(userEntity user) {
        JSONObject json = new JSONObject();
        json.put("id", user.getId());
        json.put("password", user.getPassword());
        json.put("fullname", user.getFullname());
        json.put("email", user.getEmail());
        json.put("admin", user.getAdmin());
        return json;
    }

    private String readRequestBody(BufferedReader reader) throws IOException {
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        return sb.toString();
    }

    private void sendError(HttpServletResponse response, int statusCode, String message) throws IOException {
        response.setStatus(statusCode);
        JSONObject errorJson = new JSONObject();
        errorJson.put("error", message);
        try (PrintWriter out = response.getWriter()) {
            out.print(errorJson.toString());
        }
    }
}
