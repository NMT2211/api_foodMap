package APIS;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import DAOS.UserDaoImpl;
import DAOS.VideoDaoImpl;
import ENTITYS.videoEntity;
import DAOS.UserDao;
import DAOS.VideoDao;

/**
 * Servlet implementation class listTieuPham_api
 */
@WebServlet({"/listTieuPham_api","/listTieuPham_api/*"})
public class listTieuPham_api extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final UserDao dao = new UserDaoImpl(); 
	private final VideoDao videoDao = new VideoDaoImpl(); 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public listTieuPham_api() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Thêm header CORS
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
        response.setHeader("Access-Control-Max-Age", "3600");

        // Xử lý yêu cầu OPTIONS
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            response.setStatus(HttpServletResponse.SC_OK);
            return;
        }

        super.service(request, response);
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (PrintWriter out = response.getWriter()) {
            String pathInfo = request.getPathInfo();

            if (pathInfo == null || pathInfo.equals("/")) {
                // Lấy danh sách tất cả video
                List<videoEntity> videos = videoDao.findAll();
                JSONArray jsonArray = new JSONArray();
                for (videoEntity video : videos) {
                    JSONObject json = new JSONObject();
                    json.put("id", video.getId());
                    json.put("title", video.getTitle());
                    json.put("poster", video.getPoster());
                    json.put("views", video.getViews());
                    json.put("description", video.getDescription());
                    json.put("active", video.getActive());
                    json.put("link", video.getLink());
                    jsonArray.put(json);
                }
                out.print(jsonArray.toString());
            } else {
                // Lấy thông tin video theo ID
                String id = pathInfo.substring(1); // Bỏ dấu "/"
                videoEntity video = videoDao.findById(id);

                if (video == null) {
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    out.print(new JSONObject().put("error", "Video không tồn tại").toString());
                } else {
                    // Cập nhật lượt xem
                    video.setViews(video.getViews() + 1);
                    videoDao.update(video); // Gọi phương thức cập nhật trong DAO

                    JSONObject json = new JSONObject();
                    json.put("id", video.getId());
                    json.put("title", video.getTitle());
                    json.put("poster", video.getPoster());
                    json.put("views", video.getViews());
                    json.put("description", video.getDescription());
                    json.put("active", video.getActive());
                    json.put("link", video.getLink());
                    out.print(json.toString());
                }
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            try (PrintWriter out = response.getWriter()) {
                out.print(new JSONObject().put("error", "Lỗi server: " + e.getMessage()).toString());
            }
            e.printStackTrace();
        }
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
