package APIS;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import DAOS.VideoDao;
import DAOS.VideoDaoImpl;
import ENTITYS.videoEntity;

@WebServlet({"/quanlivideo_api", "/quanlivideo_api/*"})
public class quanlivideo_api extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final VideoDao videoDao = new VideoDaoImpl();

    public quanlivideo_api() {
        super();
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
        response.setHeader("Access-Control-Max-Age", "3600");

        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            response.setStatus(HttpServletResponse.SC_OK);
            return;
        }

        super.service(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (PrintWriter out = response.getWriter()) {
            String pathInfo = request.getPathInfo();

            if (pathInfo == null || pathInfo.equals("/")) {
                List<videoEntity> videos = videoDao.findAll();
                JSONArray jsonArray = new JSONArray();
                for (videoEntity video : videos) {
                    JSONObject json = toJson(video);
                    jsonArray.put(json);
                }
                out.print(jsonArray.toString());
            } else {
                String id = pathInfo.substring(1);
                videoEntity video = videoDao.findById(id);

                if (video == null) {
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    out.print(new JSONObject().put("error", "Video không tồn tại").toString());
                } else {
                    JSONObject json = toJson(video);
                    out.print(json.toString());
                }
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            try (PrintWriter out = response.getWriter()) {
                out.print(new JSONObject().put("error", "Lỗi server: " + e.getMessage()).toString());
            }
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (BufferedReader reader = request.getReader(); PrintWriter out = response.getWriter()) {
            JSONObject inputJson = new JSONObject(readRequestBody(reader));
            videoEntity video = new videoEntity();

            video.setId(inputJson.optString("id"));
            video.setTitle(inputJson.optString("title"));
            video.setPoster(inputJson.optString("poster"));
            video.setLink(inputJson.optString("link"));
            video.setDescription(inputJson.optString("description"));
            video.setActive(inputJson.optBoolean("active", true));
            video.setViews(inputJson.optInt("views", 0));

            boolean isCreated = videoDao.create(video);

            if (isCreated) {
                response.setStatus(HttpServletResponse.SC_CREATED);
                out.print(new JSONObject().put("message", "Thêm mới video thành công").toString());
            } else {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                out.print(new JSONObject().put("error", "Không thể thêm mới video").toString());
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            try (PrintWriter out = response.getWriter()) {
                out.print(new JSONObject().put("error", "Lỗi server: " + e.getMessage()).toString());
            }
            e.printStackTrace();
        }
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (BufferedReader reader = request.getReader(); PrintWriter out = response.getWriter()) {
            JSONObject inputJson = new JSONObject(readRequestBody(reader));

            String id = inputJson.optString("id");
            videoEntity video = videoDao.findById(id);

            if (video == null) {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                out.print(new JSONObject().put("error", "Video không tồn tại").toString());
                return;
            }

            video.setTitle(inputJson.optString("title", video.getTitle()));
            video.setPoster(inputJson.optString("poster", video.getPoster()));
            video.setLink(inputJson.optString("link", video.getLink()));
            video.setDescription(inputJson.optString("description", video.getDescription()));
            video.setActive(inputJson.optBoolean("active", video.getActive()));
            video.setViews(inputJson.optInt("views", video.getViews()));

            boolean isUpdated = videoDao.update(video);

            if (isUpdated) {
                response.setStatus(HttpServletResponse.SC_OK);
                out.print(new JSONObject().put("message", "Cập nhật video thành công").toString());
            } else {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                out.print(new JSONObject().put("error", "Không thể cập nhật video").toString());
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            try (PrintWriter out = response.getWriter()) {
                out.print(new JSONObject().put("error", "Lỗi server: " + e.getMessage()).toString());
            }
            e.printStackTrace();
        }
    }
    
    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (PrintWriter out = response.getWriter()) {
            String pathInfo = request.getPathInfo();

            // Kiểm tra xem có cung cấp ID trong URL hay không
            if (pathInfo == null || pathInfo.length() <= 1) {
                sendError(response, HttpServletResponse.SC_BAD_REQUEST, "Yêu cầu không hợp lệ. Không có ID được cung cấp.");
                return;
            }

            String id = pathInfo.substring(1); // Lấy ID từ URL
            boolean isDeleted = videoDao.deleteById(id); // Gọi phương thức xóa trong DAO

            if (isDeleted) {
                // Xóa thành công, trả về phản hồi
                response.setStatus(HttpServletResponse.SC_OK);
                JSONObject successResponse = new JSONObject();
                successResponse.put("id", id);
                successResponse.put("message", "Xóa video thành công.");
                out.print(successResponse.toString());
            } else {
                // Xóa thất bại
                sendError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Không thể xóa video. Vui lòng thử lại.");
            }
        } catch (Exception e) {
            sendError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi server: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void sendError(HttpServletResponse response, int statusCode, String message) throws IOException {
        response.setStatus(statusCode);
        JSONObject errorJson = new JSONObject();
        errorJson.put("error", message);
        try (PrintWriter out = response.getWriter()) {
            out.print(errorJson.toString());
        }
    }


    private JSONObject toJson(videoEntity video) {
        JSONObject json = new JSONObject();
        json.put("id", video.getId());
        json.put("title", video.getTitle());
        json.put("poster", video.getPoster());
        json.put("views", video.getViews());
        json.put("description", video.getDescription());
        json.put("active", video.getActive());
        json.put("link", video.getLink());
        return json;
    }

    private String readRequestBody(BufferedReader reader) throws IOException {
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        return sb.toString();
    }
}
