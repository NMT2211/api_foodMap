package APIS;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import DAOS.FavoriteDao;
import DAOS.FavoriteDaoImpl;
import ENTITYS.favoriteEntity;
import ENTITYS.userEntity;
import ENTITYS.videoEntity;

/**
 * Servlet implementation class like_api
 */
@WebServlet({ "/like_api", "/like_api/*" })
public class like_api extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final FavoriteDao likeDao = new FavoriteDaoImpl();

    public like_api() {
        super();
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
        response.setHeader("Access-Control-Max-Age", "3600");

        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            response.setStatus(HttpServletResponse.SC_OK);
            return;
        }

        super.service(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (PrintWriter out = response.getWriter()) {
            // Kiểm tra path info
            String pathInfo = request.getPathInfo();
            String userId = request.getParameter("userId");

            if (pathInfo != null && pathInfo.equals("/")) {
                // Trường hợp không có userId hoặc yêu cầu lấy toàn bộ danh sách yêu thích
                List<favoriteEntity> favorites = likeDao.findAll();

                if (favorites.isEmpty()) {
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    out.print(new JSONObject().put("error", "Không tìm thấy video nào trong danh sách yêu thích").toString());
                    return;
                }

                JSONArray jsonArray = new JSONArray();
                for (favoriteEntity favorite : favorites) {
                    JSONObject json = new JSONObject();
                    
                    json.put("userId", favorite.getUser().getId());
                    json.put("videoId", favorite.getVideo().getId());
                    json.put("title", favorite.getVideo().getTitle());
                    json.put("poster", favorite.getVideo().getPoster());
                    json.put("views", favorite.getVideo().getViews());
                    json.put("description", favorite.getVideo().getDescription());
                    json.put("active", favorite.getVideo().getActive());
                    json.put("link", favorite.getVideo().getLink());
                    json.put("likeDate", favorite.getLikeDate());
                    jsonArray.put(json);
                }
                out.print(jsonArray.toString());
            } else if (userId != null && !userId.isEmpty()) {
                // Trường hợp lấy danh sách yêu thích theo userId
                List<favoriteEntity> favorites = likeDao.findLikeById(userId);

                if (favorites.isEmpty()) {
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    out.print(new JSONObject().put("error", "Người dùng không có video nào trong danh sách yêu thích").toString());
                    return;
                }

                JSONArray jsonArray = new JSONArray();
                for (favoriteEntity favorite : favorites) {
                    JSONObject json = new JSONObject();
                    json.put("userId", favorite.getUser().getId());
                    json.put("videoId", favorite.getVideo().getId());
                    json.put("title", favorite.getVideo().getTitle());
                    json.put("poster", favorite.getVideo().getPoster());
                    json.put("views", favorite.getVideo().getViews());
                    json.put("description", favorite.getVideo().getDescription());
                    json.put("active", favorite.getVideo().getActive());
                    json.put("link", favorite.getVideo().getLink());
                    json.put("likeDate", favorite.getLikeDate());
                    jsonArray.put(json);
                }
                out.print(jsonArray.toString());
            } else {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print(new JSONObject().put("error", "Vui lòng cung cấp userId hoặc sử dụng đường dẫn đúng").toString());
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            try (PrintWriter out = response.getWriter()) {
                out.print(new JSONObject().put("error", "Lỗi server: " + e.getMessage()).toString());
            }
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (PrintWriter out = response.getWriter()) {
            // Lấy dữ liệu từ request body
            String requestBody = request.getReader().lines()
                .reduce("", (accumulator, actual) -> accumulator + actual);

            JSONObject jsonBody = new JSONObject(requestBody);

            // Kiểm tra các thông tin bắt buộc
            if (!jsonBody.has("userId") || !jsonBody.has("videoId")) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print(new JSONObject().put("error", "Yêu cầu phải có userId và videoId").toString());
                return;
            }

            String userId = jsonBody.getString("userId");
            String videoId = jsonBody.getString("videoId");

            // Tạo đối tượng yêu thích mới
            favoriteEntity favorite = new favoriteEntity();
            favorite.setUser(new userEntity(userId)); // userEntity phải ánh xạ chính xác trong model
            favorite.setVideo(new videoEntity(videoId)); // videoEntity phải ánh xạ chính xác trong model
            favorite.setLikeDate(new java.util.Date()); // Ngày hiện tại

            // Thêm vào cơ sở dữ liệu
            boolean isCreated = likeDao.create(favorite);

            if (isCreated) {
                response.setStatus(HttpServletResponse.SC_CREATED);
                out.print(new JSONObject().put("message", "Đã thêm video vào danh sách yêu thích thành công").toString());
            } else {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                out.print(new JSONObject().put("error", "Không thể thêm video vào danh sách yêu thích").toString());
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            try (PrintWriter out = response.getWriter()) {
                out.print(new JSONObject().put("error", "Lỗi server: " + e.getMessage()).toString());
            }
            e.printStackTrace();
        }
    }
    
    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (PrintWriter out = response.getWriter()) {
            // Lấy dữ liệu từ request body
            String requestBody = request.getReader().lines()
                .reduce("", (accumulator, actual) -> accumulator + actual);

            JSONObject jsonBody = new JSONObject(requestBody);

            // Kiểm tra các thông tin bắt buộc
            if (!jsonBody.has("userId") || !jsonBody.has("videoId")) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print(new JSONObject().put("error", "Yêu cầu phải có userId và videoId").toString());
                return;
            }

            String userId = jsonBody.getString("userId");
            String videoId = jsonBody.getString("videoId");

            // Ghi log để kiểm tra dữ liệu nhận được
            System.out.println("Received DELETE request with userId: " + userId + " and videoId: " + videoId);

            // Xóa lượt thích khỏi cơ sở dữ liệu
            boolean isDeleted = likeDao.delete(userId, videoId);

            if (isDeleted) {
                response.setStatus(HttpServletResponse.SC_OK);
                out.print(new JSONObject().put("message", "Đã xóa lượt thích thành công").toString());
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                out.print(new JSONObject().put("error", "Không tìm thấy lượt thích để xóa").toString());
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            try (PrintWriter out = response.getWriter()) {
                out.print(new JSONObject().put("error", "Lỗi server: " + e.getMessage()).toString());
            }
            e.printStackTrace();
        }
    }



}
