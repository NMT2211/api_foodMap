package APIS;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

import DAOS.FavoriteDao;
import DAOS.FavoriteDaoImpl;
import DAOS.UserDao;
import DAOS.UserDaoImpl;
import DAOS.VideoDao;
import DAOS.VideoDaoImpl;

@WebServlet("/report_api")
public class report_api extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final UserDao userDao = new UserDaoImpl();
    private final FavoriteDao favoriteDao = new FavoriteDaoImpl();
    private final VideoDao videoDao = new VideoDaoImpl();

    public report_api() {
        super();
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
        response.setHeader("Access-Control-Max-Age", "3600");

        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            response.setStatus(HttpServletResponse.SC_OK);
            return;
        }

        super.service(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (PrintWriter out = response.getWriter()) {
            String filter = request.getParameter("filter");
            if (filter == null || filter.isEmpty()) {
                filter = "stats"; // Mặc định: Thống kê yêu thích
            }

            switch (filter.toLowerCase()) {
                case "stats":
                    handleStats(response, out);
                    break;
//                case "likedusers":
//                    handleLikedUsers(request, response, out);
//                    break;
//                case "sharedusers":
//                    handleSharedUsers(request, response, out);
//                    break;
                default:
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    out.print(new JSONObject().put("error", "Tham số filter không hợp lệ").toString());
                    break;
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            try (PrintWriter out = response.getWriter()) {
                out.print(new JSONObject().put("error", "Lỗi server: " + e.getMessage()).toString());
            }
            e.printStackTrace();
        }
    }

    private void handleStats(HttpServletResponse response, PrintWriter out) throws IOException {
        try {
            List<Object[]> stats = videoDao.findVideoLikeStats();
            JSONArray jsonArray = new JSONArray();
            for (Object[] stat : stats) {
                JSONObject json = new JSONObject();
                json.put("videoTitle", stat[0]);
                json.put("favoriteCount", stat[1]);
                json.put("oldestDate", stat[2]);
                json.put("newestDate", stat[3]);
                jsonArray.put(json);
            }
            out.print(jsonArray.toString());
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print(new JSONObject().put("error", "Lỗi khi thống kê số người yêu thích").toString());
        }
    }

//    private void handleLikedUsers(HttpServletRequest request, HttpServletResponse response, PrintWriter out) throws IOException {
//        String videoId = request.getParameter("videoId");
//        if (videoId == null || videoId.isEmpty()) {
//            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
//            out.print(new JSONObject().put("error", "Cần cung cấp video ID để lọc người yêu thích").toString());
//            return;
//        }
//
//        try {
//            List<Object[]> likedUsers = videoDao.getLikedUsersByVideo(videoId);
//            JSONArray jsonArray = new JSONArray();
//            for (Object[] user : likedUsers) {
//                JSONObject json = new JSONObject();
//                json.put("username", user[0]);
//                json.put("fullname", user[1]);
//                json.put("email", user[2]);
//                json.put("favoriteDate", user[3]);
//                jsonArray.put(json);
//            }
//            out.print(jsonArray.toString());
//        } catch (Exception e) {
//            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
//            out.print(new JSONObject().put("error", "Lỗi khi lọc người yêu thích").toString());
//        }
//    }
//
//    private void handleSharedUsers(HttpServletRequest request, HttpServletResponse response, PrintWriter out) throws IOException {
//        String videoId = request.getParameter("videoId");
//        if (videoId == null || videoId.isEmpty()) {
//            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
//            out.print(new JSONObject().put("error", "Cần cung cấp video ID để lọc người chia sẻ").toString());
//            return;
//        }
//
//        try {
//            List<Object[]> sharedUsers = favoriteDao.getSharedUsersByVideo(videoId);
//            JSONArray jsonArray = new JSONArray();
//            for (Object[] user : sharedUsers) {
//                JSONObject json = new JSONObject();
//                json.put("senderName", user[0]);
//                json.put("senderEmail", user[1]);
//                json.put("receiverEmail", user[2]);
//                json.put("sharedDate", user[3]);
//                jsonArray.put(json);
//            }
//            out.print(jsonArray.toString());
//        } catch (Exception e) {
//            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
//            out.print(new JSONObject().put("error", "Lỗi khi lọc người chia sẻ").toString());
//        }
//    }
}
