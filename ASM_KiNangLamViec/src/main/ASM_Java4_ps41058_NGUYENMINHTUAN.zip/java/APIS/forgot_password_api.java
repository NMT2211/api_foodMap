package APIS;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

import org.json.JSONObject;

import DAOS.UserDao;
import DAOS.UserDaoImpl;
import ENTITYS.userEntity;

/**
 * Servlet implementation class forgot_password_api
 */
@WebServlet("/forgot_password_api/*")
public class forgot_password_api extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final UserDao userDao = new UserDaoImpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (BufferedReader reader = request.getReader(); PrintWriter out = response.getWriter()) {
            JSONObject inputJson = new JSONObject(readRequestBody(reader));
            String pathInfo = request.getPathInfo();

            if ("/request".equals(pathInfo)) {
                String email = inputJson.optString("email");
                if (email.isEmpty()) {
                    sendError(response, HttpServletResponse.SC_BAD_REQUEST, "Email không được để trống.");
                    return;
                }

                userEntity user = userDao.findIdorEmail(email);
                if (user == null) {
                    sendError(response, HttpServletResponse.SC_NOT_FOUND, "Email không tồn tại.");
                    return;
                }

                String resetCode = generateResetCode();
                user.setResetCode(resetCode);
                userDao.update(user); // Cập nhật reset code

                sendEmail(email, "Mã xác nhận đặt lại mật khẩu: " + resetCode);

                response.setStatus(HttpServletResponse.SC_OK);
                JSONObject successResponse = new JSONObject();
                successResponse.put("message", "Mã xác nhận đã được gửi đến email của bạn.");
                out.print(successResponse.toString());
            } else {
                sendError(response, HttpServletResponse.SC_BAD_REQUEST, "Đường dẫn không hợp lệ.");
            }
        } catch (Exception e) {
            sendError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi server: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (BufferedReader reader = request.getReader(); PrintWriter out = response.getWriter()) {
            JSONObject inputJson = new JSONObject(readRequestBody(reader));
            String pathInfo = request.getPathInfo();

            if ("/reset".equals(pathInfo)) {
                String resetCode = inputJson.optString("resetCode");
                String newPassword = inputJson.optString("newPassword");

                if (resetCode.isEmpty() || newPassword.isEmpty()) {
                    sendError(response, HttpServletResponse.SC_BAD_REQUEST, "Thông tin không đầy đủ.");
                    return;
                }

                userEntity user = userDao.findByResetCode(resetCode);
                if (user == null) {
                    sendError(response, HttpServletResponse.SC_NOT_FOUND, "Mã xác nhận không hợp lệ hoặc đã hết hạn.");
                    return;
                }

                if (newPassword.length() < 6) {
                    sendError(response, HttpServletResponse.SC_BAD_REQUEST, "Mật khẩu mới phải có ít nhất 6 ký tự.");
                    return;
                }

                user.setPassword(newPassword);
                user.setResetCode(null); // Xóa reset code sau khi sử dụng
                userDao.update(user);

                response.setStatus(HttpServletResponse.SC_OK);
                JSONObject successResponse = new JSONObject();
                successResponse.put("message", "Mật khẩu đã được đặt lại thành công.");
                out.print(successResponse.toString());
            } else {
                sendError(response, HttpServletResponse.SC_BAD_REQUEST, "Đường dẫn không hợp lệ.");
            }
        } catch (Exception e) {
            sendError(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi server: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void sendEmail(String email, String message) {
        // Giả lập gửi email
        System.out.println("Email sent to " + email + ": " + message);
    }

    private String generateResetCode() {
        return String.valueOf((int) (Math.random() * 900000) + 100000); // Mã 6 chữ số
    }

    private String readRequestBody(BufferedReader reader) throws IOException {
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        return sb.toString();
    }

    private void sendError(HttpServletResponse response, int statusCode, String message) throws IOException {
        response.setStatus(statusCode);
        JSONObject errorJson = new JSONObject();
        errorJson.put("error", message);
        try (PrintWriter out = response.getWriter()) {
            out.print(errorJson.toString());
        }
    }
}
