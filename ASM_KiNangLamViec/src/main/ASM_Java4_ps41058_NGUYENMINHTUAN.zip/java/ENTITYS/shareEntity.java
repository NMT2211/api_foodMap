package ENTITYS;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor 
@AllArgsConstructor
@Entity
@Table(name = "shares", uniqueConstraints = @UniqueConstraint(columnNames = {"UserId", "VideoId"}))
public class shareEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "VideoId", nullable = false)
    private videoEntity video;

    @ManyToOne
    @JoinColumn(name = "UserId", nullable = false)
    private userEntity user;

    @Column(name = "Emails")
    private String emails;
    
    @Temporal(TemporalType.DATE)
    @Column(name = "ShareDate")
    private Date shareDate;

	public shareEntity( videoEntity video, userEntity user, String emails, Date shareDate) {
		super();
		
		this.video = video;
		this.user = user;
		this.emails = emails;
		this.shareDate = shareDate;
	}
	
	

    
    
    
}
