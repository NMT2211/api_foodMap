package ENTITYS;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@NoArgsConstructor 
@AllArgsConstructor
@Entity
@Table(name = "Videos")
public class videoEntity {
    @Id
    @Column(name = "Id", length = 50)
    private String id;

    @Column(name = "Title", length = 255, nullable = false)
    private String title;

    @Column(name = "Poster", length = 255)
    private String poster;

    @Column(name = "Views")
    private Integer views = 0;

    @Column(name = "Description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "Active", nullable = false)
    private Boolean active = true;

    @Column(name = "Link")
    private String  link;
    
    @OneToMany(mappedBy = "video")
    private List<favoriteEntity> favorites;

    @OneToMany(mappedBy = "video")
    private List<shareEntity> shares;
    
    public videoEntity(String id) {
        this.id = id;
    }
    
}
