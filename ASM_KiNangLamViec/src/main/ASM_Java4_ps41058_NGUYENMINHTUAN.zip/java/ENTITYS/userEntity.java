package ENTITYS;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor 
@AllArgsConstructor
@Entity
@Table(name="users")
public class userEntity {
	@Id
    private String id;
    
    @Column(name = "password")
    private String password;
    
    @Column(name = "fullname", columnDefinition = "nvarchar")
    private String fullname;
    
    @Column(name = "email")
    private String email;
    
    @Column(name = "admin")
    private Boolean admin;
    
    @OneToMany(mappedBy = "user")
    private List<favoriteEntity> favorites;
    
    @OneToMany(mappedBy = "user")
    private List<shareEntity> shares;
    
    @Column(name = "reset_code", nullable = true)
    private String resetCode;

    public userEntity(String id) {
        this.id = id;
    }
}
